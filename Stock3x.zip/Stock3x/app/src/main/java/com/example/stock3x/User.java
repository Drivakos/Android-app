package com.example.stock3x;


public class User {
    public String deptname, email;

    public User(){

    }

    public User(String name, String email) {
        this.deptname = name;
        this.email = email;

    }
}
