package com.example.stock3x;
public class Items {
    private String itemname;
    private String itemcategory;
    private String itemprice;



    public Items(String itemnameValue, String itemcategoryValue, String itempriceValue) {

    }

    public Items(String itemname,String itemcategory,String itemprice,String itembarcode){

        this.itemname=itemname;
        this.itemcategory=itemcategory;
        this.itemprice=itemprice;

    }

    public String getItemname() {
        return itemname;
    }

    public String getItemcategory() {
        return itemcategory;
    }

    public String getItemprice() {
        return itemprice;
    }


}